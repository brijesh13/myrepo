package com.example.daffolap_172.servicesdemo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    //alarm Manager
    AlarmManager mAlarmManager;
    TimePicker mTimePicker;
    TextView mUpdateText;
    Context mContext;
    Button mAlarm_on,mAlarm_off;
    Intent intent;
    PendingIntent mPendingIntent;
    long minutes,hour;
    String hour_str,minutes_str;
    Calendar calendar;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.mContext=this;

        mAlarmManager=(AlarmManager) getSystemService(ALARM_SERVICE);

        mTimePicker=(TimePicker)findViewById(R.id.time_picker);

        mTimePicker.setIs24HourView(false);

        mUpdateText=(TextView)findViewById(R.id.update_text);

        mAlarm_on =(Button)findViewById(R.id.alarm_on);

        mAlarm_off =(Button)findViewById(R.id.alarm_off);

        hour=mTimePicker.getHour();

        minutes=mTimePicker.getMinute();

        calendar=Calendar.getInstance();

        intent=new Intent(this.mContext,AlarmReceiver.class);


        mTimePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                // display a toast with changed values of time picker

                hour_str=String.valueOf(hourOfDay);

                minutes_str=String.valueOf(minute);

                Toast.makeText(getApplicationContext(), hourOfDay + " " + minute, Toast.LENGTH_SHORT).show();
                mUpdateText.setText(" Now Time is :: " + hourOfDay + " : " + minute);
            }
        });

        mAlarm_on.setOnClickListener(new OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {


                Date futureDate = new Date(new Date().getTime() + 86400000);

                long trigTimeMills;
                hour=mTimePicker.getHour();
                minutes=mTimePicker.getMinute();

                futureDate.setHours((int) hour);
                futureDate.setMinutes((int) minutes);

                setAlarm("Alram set to"+hour_str+":"+minutes_str);

                intent.putExtra("extra","alarm on");

                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR, mTimePicker.getHour());
                calendar.set(Calendar.MINUTE  , mTimePicker.getMinute());
                Calendar calendarCur = Calendar.getInstance();


                long diff=(int)(futureDate.getTime()-calendar.getTimeInMillis())/1000;

                Log.i("MainActivity", "future diff "+diff+"");
                Log.i("MainActivity", "current date set"+calendar.getTimeInMillis()+"");
                Log.i("MainActivity", "current date"+calendarCur.getTimeInMillis()+"");

                mPendingIntent=PendingIntent.getBroadcast(MainActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);

                mAlarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),mPendingIntent);
            }
        });
        mAlarm_off.setOnClickListener(new OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                mAlarmManager.cancel(mPendingIntent);

                intent.putExtra("extra","alarm off");

                setAlarm("Alarm Off!");
            }
        });

    }
    private void setAlarm(String text)
    {
        mUpdateText.setText(text);
    }
    @Override
    public void onClick(View view) {

    }
}
