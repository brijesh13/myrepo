package com.example.daffolap_172.databinding;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view);
    void showDetails(View view);

}
