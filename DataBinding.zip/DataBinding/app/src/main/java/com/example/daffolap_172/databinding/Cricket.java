package com.example.daffolap_172.databinding;

import android.content.Context;
import android.databinding.DataBindingUtil;
//import android.databinding.generated.callback.OnClickListener;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.example.daffolap_172.databinding.databinding.ActivityMainBinding;
import com.example.daffolap_172.databinding.databinding.CricketBinding;
import com.example.daffolap_172.databinding.databinding.TestBinding;


import java.util.ArrayList;

public class Cricket extends ArrayAdapter<Icons> implements View.OnClickListener {

    private Context mContext;
    CricketBinding binding;
    TestBinding imgBinding;
    static int imagePos;
    ActivityMainBinding activityMainBinding;
    private ArrayList<Icons> iconsArrayList=new ArrayList<>();
    private ItemClickListener mListener;

    public Cricket(Context context, ArrayList<Icons> arrayList, ItemClickListener mListener)
    {
        super(context,0,arrayList);
        mContext=context;
        iconsArrayList=arrayList;
        this.mListener = mListener;
    }
    // Return the size of your dataset (invoked by the layout manager)
    @NonNull
    public int getItemCount() {
        return iconsArrayList.size();
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        imagePos=position;

        if(convertView == null){
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cricket, null);
            binding = DataBindingUtil.bind(convertView);
            //convertView.setTag(binding);
        }else{
            binding = (CricketBinding) convertView.getTag();
        }
        convertView.findViewById(R.id.imageView).setTag(position);

        //View popupView = LayoutInflater.from(mContext).inflate(R.layout.test, null);

        //imgBinding = DataBindingUtil.bind(popupView);
        //imgBinding.setIconsi(iconsArrayList.get(position));

        Log.i("hii",position+"");
        binding.setIcons(iconsArrayList.get(position));
        binding.setCallback(mListener);
        return binding.getRoot();

    }

    @Override
    public void onClick(View view) {
        Log.i("hiii","hello");

    }

}
