package widget;

public class CheckListItem {
    public String heading;
}
