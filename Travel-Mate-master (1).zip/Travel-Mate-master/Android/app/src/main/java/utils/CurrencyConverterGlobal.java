package utils;

public class CurrencyConverterGlobal {
    public static int global_image_id;
    public static String global_country_name;
    public static String country_id;
}
